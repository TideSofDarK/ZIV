local size = 35
local count = 11

local numbers = size * count

local n = 1
for c=1,count do
	local file = io.open("ziv_damage_"..tostring(size * c)..".mks", "w+")
	io.output(file)
	for i=0,size-1 do
	  io.write("sequence-rgba "..tostring(i).."\n")
	  io.write("frame "..tostring(n)..".tga 1".."\n")
	  n = n + 1
	end
	io.close(file)
end