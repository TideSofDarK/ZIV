"use strict";
//var data = fullData;
var numbers = 400;
var row = 20;
var fontSize = 40;
var cellSize = fontSize * 2;

var canvas = document.createElement("canvas");
canvas.id = "canvas";

document.body.appendChild(canvas);

var cnv = document.getElementById("canvas"),
ctx = cnv.getContext('2d');
ctx.imageSmoothingEnabled=true;

var count = 400;

window.onload = function(){
    ctx.canvas.width = cellSize;
    ctx.canvas.height = cellSize;

    ctx.font = fontSize + 'px "SF New Republic SC Bold Italic"';
    ctx.textAlign = 'center';
    ctx.fillStyle = 'white';
    ctx.strokeStyle = 'black';

    var i = 0;
    for (var y = 0; y < row; y++) {
	    for (var x = 0; x < row; x++) {
	    	ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
	    	i++;
	    	// ctx.rect((x + 0.0) * cellSize,(y + 0) * cellSize,cellSize,cellSize);
	    	// ctx.stroke();
	    	ctx.fillText(i, (0 + 0.475) * cellSize, (0 + 0.65) * cellSize);
	    	ctx.strokeText(i, (0 + 0.475) * cellSize, (0 + 0.65) * cellSize);

	        var dataURL = cnv.toDataURL();
	        $.ajax({
	            type: "POST",
	            url: "php/save.php",
	            data: { 
	                imgBase64: dataURL,
	                fileName: i
	            }
	        }).done(function(o) {
	          console.log(o); 
	          // If you want the file to be visible in the browser 
	          // - please modify the callback in javascript. All you
	          // need is to return the url to the file, you just saved 
	          // and than put the image in your browser.
	        });
	    }
    }
}