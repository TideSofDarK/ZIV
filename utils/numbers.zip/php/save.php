<?php
	// requires php5
	define('UPLOAD_DIR', '../generic/');
	$img = $_POST['imgBase64'];
	$img = str_replace('data:image/png;base64,', '', $img);
	$img = str_replace(' ', '+', $img);
	$data = base64_decode($img);

	$file = UPLOAD_DIR . $_POST['fileName'] . '.tga';

	$im = new Imagick ();
	$im->newImage (80, 80, "white");
	$im->readimageblob($data);
	$im->setImageFormat ("tga");
	file_put_contents ($file, $im);

	// $success = file_put_contents($file, $data);
	// print $success ? $file : 'Unable to save the file.';
?>