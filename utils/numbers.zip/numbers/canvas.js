"use strict";
//var data = fullData;

var canvas = document.createElement("canvas");
canvas.id = "canvas";

document.body.appendChild(canvas);

var cnv = document.getElementById("canvas"),
ctx = cnv.getContext('2d');
ctx.imageSmoothingEnabled=true;

var count = 400;

window.onload = function(){
    ctx.canvas.width = 40
    ctx.canvas.height = count * 20;

    ctx.font="20px Verdana";
    
    for(var i = 0; i < count + 1; i++) {
        ctx.fillText(i, 0, -4 + i * 20);
    }
}