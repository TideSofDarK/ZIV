"use strict";
//var data = fullData;

var canvas = document.createElement("canvas");
canvas.id = "canvas";

document.body.appendChild(canvas);

var cnv = document.getElementById("canvas"),
ctx = cnv.getContext('2d');
ctx.imageSmoothingEnabled=true;

function loadImage(dataURL, x, y) {
    var canvas = document.getElementById('canvas');
    var ctx = canvas.getContext('2d');

    // load image from data url
    var imageObj = new Image();
    imageObj.onload = function() {
        ctx.drawImage(this, x, y);
    };

    imageObj.src = dataURL;
}

function clippingPath(pathPoints, img, x, y){
    // save the unclipped context
    ctx.save();

    // define the path that will be clipped to
    ctx.beginPath();
    ctx.moveTo(pathPoints[0],pathPoints[1]);
    // this demo has a known number of polygon points
    // but include a loop of "lineTo's" if you have a variable number of points
    ctx.lineTo(pathPoints[2],pathPoints[3]);
    ctx.lineTo(pathPoints[4],pathPoints[5]);
    ctx.closePath();    

    // make the current path a clipping path
    ctx.clip();

    // draw the image which will be clipped except in the clipping path
    if (img)
        ctx.drawImage(img, x, y, 24, 24);

    // restore the unclipped context (==undo the clipping path)
    ctx.restore();
}

function getTypeImageUrl( type ) {
    var img = 'misc';
    
    if (/cd/.test(type))
        img = 'cd';
    if (/chance/.test(type))
        img = 'chance';
    if (/damage/.test(type))
        img = 'damage';
    if (/delay/.test(type))
        img = 'delay';
    if (/radius/.test(type))
        img = 'radius'; 
    if (/range/.test(type))
        img = 'range';
    if (/speed/.test(type))
        img = 'speed';         
    
    return 'images/letters/' + img + '.png';
}
    
function drawImage(name, itemImageURL, abilityImageURL, x, y, size, type) {
    var canvas = document.getElementById('canvas');
    var ctx = canvas.getContext('2d');

    var width = 91;

    var itemImage = new Image();
    itemImage.onload = function() {
        var itImg = this;
        
        // load image from data url
        var abilityImage = new Image();
        abilityImage.onload = function() {
            var abilityImage = this;
            
            var paramImg = new Image();
            paramImg.onload = function() {
                ctx.drawImage(itImg, x, y);
                clippingPath([x + width - size, y, x + width, y, x + width, y + size], abilityImage, x + width - size, y);
                clippingPath([x, y, x + size, y, x, y + size], this, x, y);

                var dataURL = cnv.toDataURL();
                $.ajax({
                    type: "POST",
                    url: "save.php",
                    data: { 
                        imgBase64: dataURL,
                        fileName: name
                    }
                }).done(function(o) {
                  console.log(o); 
                  // If you want the file to be visible in the browser 
                  // - please modify the callback in javascript. All you
                  // need is to return the url to the file, you just saved 
                  // and than put the image in your browser.
                });
            };
            
            paramImg.src = getTypeImageUrl( type );   
        };

        abilityImage.src = abilityImageURL; 
    };

    itemImage.src = itemImageURL;
}

function getAbilityImageParam( modifierName ){
    var words = modifierName.split('_');
    for(var i = 1; i < words.length - 1; i++){
        var abilityName = words.slice(0, words.length - i).join('_');
        var param = words.slice(words.length - i).join('_');
        
        if (data.abilities[abilityName])
            return [data.abilities[abilityName].img, param];
    }

    return ['ziv_empty', 'misc'];
}

window.onload = function(){
    var runes = [];
    var regex = 'item_rune_';
    
    var x = 0;
    var y = 0;
    
    var count = Object.keys(data.items).filter(function(key){
        return /item_rune_/.test(key)
    }).length;
    
    ctx.canvas.width = 124//1240;
    ctx.canvas.height = 64//count / 10 * 64;
    
    for(var k in data.items)
    {
        var item = data.items[k];
        if (/item_rune_/.test(k)){
            var img = item.img;            
            var abilityData = getAbilityImageParam(item.modifier);
            drawImage(item.name, 'images/items/' + img +'.png', 'images/spellicons/' +  abilityData[0] +'.png', x, y, 24, abilityData[1]);
            
            /*x += 124;
            if (x > 1240) {
                y += 64;
                x = 0;
            }*/
        }
    }
}